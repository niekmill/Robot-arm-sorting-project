#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import curses
import sys
import signal


class TeleopRobotArm:
    def __init__(self, topic="/locobot/mobile_base/commands/velocity", arm_topic="/locobot/arm_controller/command"):
        self.topic = topic
        self.arm_topic = arm_topic

        # Speed variables for mobile base
        self.linear_speed = 0.0
        self.angular_speed = 0.0

        # Joint positions for the arm
        self.joint_positions = [0.0] * 6  # 6 joints

        # Initialize ROS node and publishers
        rospy.init_node('teleop_robot_arm')
        self.base_pub = rospy.Publisher(self.topic, Twist, queue_size=10)
        self.arm_pub = rospy.Publisher(self.arm_topic, JointTrajectory, queue_size=10)
        self.rate = rospy.Rate(10)  # set as 10Hz

        # Initialize curses screen
        self.screen = curses.initscr()
        curses.cbreak()
        self.screen.keypad(True)
        curses.noecho()
        self.screen.clear()

        # Print instructions
        self.print_instructions()
        
    def print_instructions(self):
        self.screen.addstr(0, 0, "Use arrow keys to control the robot's base:")
        self.screen.addstr(2, 0, "    up    : increase linear speed")
        self.screen.addstr(3, 0, "    down  : decrease linear speed")
        self.screen.addstr(4, 0, "    left  : increase angular speed")
        self.screen.addstr(5, 0, "    right : decrease angular speed")
        self.screen.addstr(7, 0, "Use 'a'/'d' to control arm joints:")
        self.screen.addstr(8, 0, "    a : Increase joint 1")
        self.screen.addstr(9, 0, "    d : Decrease joint 1")
        self.screen.addstr(11, 0, "Current speeds and joint positions:")
        self.screen.refresh()

    def run(self):
        # Set signal handler for SIGINT 
        signal.signal(signal.SIGINT, self.cleanup)

        while not rospy.is_shutdown():
            # Get input from the user
            key = self.screen.getch()
            self.control_base(key)
            self.control_arm(key)

            # Publish Twist message for the mobile base
            twist = Twist()
            twist.linear.x = self.linear_speed
            twist.angular.z = self.angular_speed
            self.base_pub.publish(twist)

            # Create JointTrajectory message for the arm
            trajectory_msg = JointTrajectory()
            trajectory_msg.joint_names = ['waist', 'shoulder', 'elbow', 'forearm_roll', 'wrist_angle', 'wrist_rotate']
            point = JointTrajectoryPoint()
            point.positions = self.joint_positions
            point.time_from_start = rospy.Duration(0.1)  # Short duration for continuous control
            trajectory_msg.points.append(point)
            self.arm_pub.publish(trajectory_msg)

            # Display current speeds and joint positions
            self.display_status()

            self.rate.sleep()

    def control_base(self, key):
        if key == curses.KEY_UP:
            self.linear_speed = min(self.linear_speed + 0.1, 1.0)
        elif key == curses.KEY_DOWN:
            self.linear_speed = max(self.linear_speed - 0.1, -1.0)
        elif key == curses.KEY_LEFT:
            self.angular_speed = min(self.angular_speed + 0.1, 1.0)
        elif key == curses.KEY_RIGHT:
            self.angular_speed = max(self.angular_speed - 0.1, -1.0)

    def control_arm(self, key):
        if key == ord('a'):
            self.joint_positions[0] += 0.1  # Increase joint 1 (waist)
        elif key == ord('d'):
            self.joint_positions[0] -= 0.1  # Decrease joint 1 (waist)

    def display_status(self):
        self.screen.addstr(12, 0, "    linear : {:.1f}".format(self.linear_speed))
        self.screen.addstr(13, 0, "    angular: {:.1f}".format(self.angular_speed))
        self.screen.addstr(14, 0, "    joint 1: {:.2f}".format(self.joint_positions[0]))
        self.screen.refresh()

    def cleanup(self, signal, frame):
        # Stop the robot when the program quits
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.base_pub.publish(twist)

        # Restore terminal settings
        curses.nocbreak()
        self.screen.keypad(False)
        curses.echo()
        curses.endwin()

        sys.exit(0)


if __name__ == '__main__':
    topic = "/locobot/mobile_base/commands/velocity"
    arm_topic = "/locobot/arm_controller/command"
    if len(sys.argv) > 1:
        topic = sys.argv[1]
    if len(sys.argv) > 2:
        arm_topic = sys.argv[2]

    try:
        teleop = TeleopRobotArm(topic, arm_topic)
        teleop.run()
    except rospy.ROSInterruptException:
        pass
