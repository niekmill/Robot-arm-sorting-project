#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class ColorObjectDetector:
    def __init__(self):
        rospy.init_node('color_object_detector_node', anonymous=True)

        # Set up subscribers for the camera RGB image and depth image
        rospy.Subscriber('/locobot/camera/color/image_raw', Image, self.camera_callback)
        rospy.Subscriber('/locobot/camera/aligned_depth_to_color/image_raw', Image, self.depth_callback)

        # Initialize CvBridge
        self.bridge = CvBridge()

        # Placeholder for depth image
        self.depth_image = None

    def depth_callback(self, data):
        try:
            # Convert the ROS depth image message to OpenCV format
            self.depth_image = self.bridge.imgmsg_to_cv2(data, "32FC1")
        except CvBridgeError as e:
            rospy.logerr(f"Error converting ROS depth image message to OpenCV format: {e}")

    def camera_callback(self, data):
        try:
            # Convert the ROS image message to OpenCV format for color images
            image = self.bridge.imgmsg_to_cv2(data, "bgr8")
            # Call the method to detect red and blue objects
            self.detect_red_and_blue_objects(image)
        except CvBridgeError as e:
            rospy.logerr(f"Error converting ROS image message to OpenCV format: {e}")

    def detect_red_and_blue_objects(self, image):
        # Convert the image to the HSV color space
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Define the color ranges for red and blue
        red_lower = np.array([0, 100, 50])
        red_upper = np.array([10, 255, 255])

        blue_lower = np.array([100, 150, 0])
        blue_upper = np.array([140, 255, 255])

        # Create masks for red and blue colors
        red_mask = cv2.inRange(hsv, red_lower, red_upper)
        blue_mask = cv2.inRange(hsv, blue_lower, blue_upper)

        # Find contours for red and blue objects
        red_contours, _ = cv2.findContours(red_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        blue_contours, _ = cv2.findContours(blue_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Process red object contours
        for contour in red_contours:
            cv2.drawContours(image, [contour], -1, (0, 0, 255), 2)  # Draw red contours in red color
            self.measure_distance_to_object(contour, "red", image)
            self.calculate_object_size(contour, "red", image)

        # Process blue object contours
        for contour in blue_contours:
            cv2.drawContours(image, [contour], -1, (255, 0, 0), 2)  # Draw blue contours in blue color
            self.measure_distance_to_object(contour, "blue", image)
            self.calculate_object_size(contour, "blue", image)

        # Display the resulting image with detected objects highlighted
        cv2.imshow("Detected Red and Blue Objects", image)
        cv2.waitKey(1)  # Allow OpenCV to process the window events

    def calculate_object_size(self, contour, color, image):
        # Calculate the contour area (in pixels)
        area = cv2.contourArea(contour)
        rospy.loginfo(f"Area of the {color} object: {area} pixels.")

        # Get the bounding box around the contour
        x, y, w, h = cv2.boundingRect(contour)
        rospy.loginfo(f"Bounding box of the {color} object: width={w} pixels, height={h} pixels.")
        if area < 9000:
            rospy.loginfo("Its small")

        # Optionally, display the bounding box on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 255, 255), 2)  # Draw white rectangle for bounding box
        cv2.putText(image, f"{color} size: {w}x{h}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)


    def measure_distance_to_object(self, contour, color, image):
        if self.depth_image is None:
            return  # Skip if depth image is not available

        # Get the centroid of the object (use the contour's center)
        M = cv2.moments(contour)
        if M['m00'] > 0:
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])

            # Get the depth at the centroid from the depth image
            depth_value = self.depth_image[cy, cx]

            # Get the dimensions of the image
            image_height, image_width = image.shape[:2]

            # Calculate the center of the image
            center_x = image_width // 2
            center_y = image_height // 2

            # Check if the object is centered within a tolerance
            tolerance = 75  # Pixel tolerance for how close to the center is considered aligned
            if abs(cx - center_x) < tolerance and abs(cy - center_y) < tolerance:
                rospy.loginfo(f"The {color} object is straight in front of the camera.")
            else:
                rospy.loginfo(f"The {color} object is not centered. (cx, cy): ({cx}, {cy}), center: ({center_x}, {center_y})")

            if np.isnan(depth_value):
                rospy.logwarn(f"Depth value at the centroid for {color} object is NaN.")
            else:
                rospy.loginfo(f"Distance to the {color} object: {depth_value} meters.")
                # Optionally, display the distance on the image
                cv2.putText(image, f"{depth_value:.2f}m", (cx, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

if __name__ == '__main__':
    try:
        color_detector = ColorObjectDetector()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
