#!/usr/bin/env python3
import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import Float64

from red_blue_detector.color_detector import measure_distance_to_object

#import sensor_msgs.point_cloud2 as pc2

class GraspAndDrop:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('grasp_and_drop_node')
        
        # Publishers for the arm and gripper
        self.arm_pub = rospy.Publisher('locobot/arm_controller/command', JointTrajectory, queue_size=10)
        self.gripper_pub = rospy.Publisher('locobot/gripper_controller/command', JointTrajectory, queue_size=10)
        self.tilt_pub = rospy.Publisher('/locobot/tilt_controller/command', Float64, queue_size=10)
        self.pan_pub = rospy.Publisher('/locobot/pan_controller/command', Float64, queue_size=10)

        # Wait until the publishers are ready
        rospy.sleep(1)

    def detect_closest_object(self):
    
        objects = measure_distance_to_object()  # Implement this function
        if not objects:
            rospy.loginfo("No objects detected.")
            return None

        # Find the closest object (smallest distance)
        closest_object = min(objects, key=lambda obj: obj['distance'])
        return closest_object

    def grasp_object(self):
        # Move arm to the position of the object and close the gripper
        closest_object = self.detect_closest_object()
        if closest_object:
            self.move_arm_to_position(closest_object['position'])  # Implement this function
            self.close_gripper()  # Implement this function
            rospy.loginfo("Object grasped!")

    def drop_object(self, detected_color):
        # Move to the corresponding drop zone based on color
        drop_zone = self.get_drop_zone(detected_color)  # Implement this function
        self.move_arm_to_position(drop_zone)  # Move to drop zone
        self.open_gripper()  # Open the gripper to drop the object
        rospy.loginfo("Object dropped!")

    #to be fixed
    # def get_drop_zone(self, detected_color):
    #     # Placeholder function to return the drop zone based on color
    #     if detected_color == "red":
    #         return [x_red, y_red, z_red]  
    #     elif detected_color == "blue":
    #         return [x_blue, y_blue, z_blue] 
    #     return None

    def execute(self):
        # Main loop
        while not rospy.is_shutdown():
            detected_color = self.detect_color_from_camera()  # Implement the color detection logic
            if detected_color:
                self.grasp_object()
                self.drop_object(detected_color)
            else:
                rospy.loginfo("No color detected.")

if __name__ == "__main__":
    try:
        grasp_and_drop = GraspAndDrop()
        grasp_and_drop.execute()
    except rospy.ROSInterruptException:
        pass
