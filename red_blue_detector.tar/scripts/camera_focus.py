#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist
from locobot_simulation.msg import BoundingBoxes, BoundingBox 
import time

class PublisherNode:
    def __init__(self):
        # Initialize node
        rospy.init_node('publisher_node', anonymous=True)

        # Create publishers for pan and tilt commands
        self.pan_publisher = rospy.Publisher('/locobot/pan_controller/command', Float64, queue_size=10)
        self.tilt_publisher = rospy.Publisher('/locobot/tilt_controller/command', Float64, queue_size=10)
        self.move_back_pub = rospy.Publisher("/locobot/mobile_base/commands/velocity", Twist, queue_size=10)

        twist = Twist()
        twist.linear.x = -0.5
        self.move_back_pub.publish(twist)
        time.sleep(3)
        twist.linear.x = 0
        self.move_back_pub.publish(twist)
        rospy.loginfo("Works")

        # Publisher for the closest object information
        self.closest_object_pub = rospy.Publisher('/closest_object', BoundingBox, queue_size=10)

        # Set the publishing rate
        self.rate = rospy.Rate(10)  # 10 Hz for smoother tracking

        # Set initial commands for pan & tilt
        self.pan_cmd = 0
        self.tilt_cmd = 0.6

        # Subscribe to the detected bounding boxes
        rospy.Subscriber('/detected_objects', BoundingBoxes, self.detection_callback)

    def detection_callback(self, detected_boxes):
        if detected_boxes.bounding_boxes:
            # Focus on the first detected object (could be modified for tracking multiple)
            closest_box = None
            closest_distance = float('inf')  # Initialize with infinity
            
            # image dimensions are assumed to be 640 x 480
            image_width = 640
            image_height = 480
            
            for box in detected_boxes.bounding_boxes:
                # Calculate the center of the bounding box
                center_x = (box.xmin + box.xmax) / 2
                center_y = (box.ymin + box.ymax) / 2
                
                # Calculate distance from the center of the image
                distance = ((center_x - (image_width / 2)) ** 2 + (center_y - (image_height / 2)) ** 2) ** 0.5
                
                # Check if this is the closest object
                if distance < closest_distance:
                    closest_distance = distance
                    closest_box = box
            
            if closest_box is not None:
                # Update pan and tilt commands if there is closest object
                self.update_pan_tilt(closest_box)
                
                # Publish the closest object information
                self.closest_object_pub.publish(closest_box)

    def update_pan_tilt(self, box):
        # Calculate target pan and tilt values
        center_x = (box.xmin + box.xmax) / 2
        center_y = (box.ymin + box.ymax) / 2
        
        # Assuming the image dimensions
        image_width = 640
        image_height = 480
        
        pan_target = (center_x - (image_width / 2)) / (image_width / 2) * 1.8  # Map to [-1.8, 1.8]
        tilt_target = (center_y - (image_height / 2)) / (image_height / 2) * 0.6  # Map to [0, 0.6]

        # Update pan and tilt commands
        self.pan_cmd = max(-1.8, min(1.8, pan_target))  # Clamp values
        self.tilt_cmd = max(0.0, min(0.6, tilt_target))  #same

    def publish_topics(self):
        while not rospy.is_shutdown():
            # Create messages
            topic1_msg = self.pan_cmd
            topic2_msg = self.tilt_cmd

            # Publish messages
            #rospy.loginfo('Publishing pan: {:.2f}, tilt: {:.2f}'.format(self.pan_cmd, self.tilt_cmd))
            self.pan_publisher.publish(topic1_msg)
            self.tilt_publisher.publish(topic2_msg)

            # Sleep to maintain the publishing rate
            self.rate.sleep()

if __name__ == '__main__':
    try:
        publisher_node = PublisherNode()
        publisher_node.publish_topics()
    except rospy.ROSInterruptException:
        pass
