#!/usr/bin/env python3
import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

def extend_arm_to_full():
    rospy.init_node('arm_control_node')
    pub = rospy.Publisher('locobot/arm_controller/command', JointTrajectory, queue_size=10)
    rospy.sleep(1)

    trajectory_msg = JointTrajectory()
    trajectory_msg.joint_names = ['waist', 'shoulder', 'elbow', 'forearm_roll', 'wrist_angle', 'wrist_rotate']

    point = JointTrajectoryPoint()
    point.positions = [0.0, 0.0, -1.57, 0.0, 1.57, 0.0]
    point.time_from_start = rospy.Duration(3.0)

    trajectory_msg.points.append(point)
    pub.publish(trajectory_msg)

    rospy.loginfo("Arm extension command published!")
    
if __name__ == "__main__":
    try:
        extend_arm_to_full()
    except rospy.ROSInterruptException:
        pass
