#!/usr/bin/env python3
import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import Float64


def extend_arm_to_full():
    # Initialize the ROS node
    rospy.init_node('arm_control_node')
    # Create a publisher for the arm controller's command topic
    pub = rospy.Publisher('locobot/arm_controller/command', JointTrajectory, queue_size=10)
    tilt_publisher = rospy.Publisher('/locobot/tilt_controller/command', Float64, queue_size=10)
    pan_publisher = rospy.Publisher('/locobot/pan_controller/command', Float64, queue_size=10)
    # Wait until the publisher is ready
    rospy.sleep(1)

    # Create a JointTrajectory message
    trajectory_msg = JointTrajectory()

    trajectory_msg.joint_names = ['waist', 'shoulder', 'elbow', 'forearm_roll', 'wrist_angle', 'wrist_rotate']
    # Create a JointTrajectoryPoint
    point = JointTrajectoryPoint()
    #Extension for grabbing [0.0, 1.52, -1.57, 0.0, 1.57, 0.0] for grabbing
    #Extension for looking around [1.57, 1.53, -1.57, 0.0, 1.57, 0.0]
    point.positions = [1.57, 1.53, -1.57, 0.0, 1.57, 0.0]
    point.time_from_start = rospy.Duration(3.0)

    # Add the point to the trajectory
    trajectory_msg.points.append(point)

    # Publish the trajectory command
    pub.publish(trajectory_msg)

    rospy.loginfo("Arm extension command published!")
    tilt = 0.6
    pan = 0.0
    tilt_publisher.publish(tilt)
    pan_publisher.publish(pan)
    rospy.loginfo("Camera moved successfully!")

if __name__ == "__main__":
    try:
        extend_arm_to_full()
    except rospy.ROSInterruptException:
        pass
