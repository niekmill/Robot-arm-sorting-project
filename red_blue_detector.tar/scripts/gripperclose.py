#!/usr/bin/env python3


####PERFECT DISTANCE 0.72m, or 0.769m
import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

def control_gripper_with_publisher():
    # Initialize the ROS node
    rospy.init_node('gripper_control_node_publisher')

    # Create a publisher for the gripper controller command
    pub = rospy.Publisher('locobot/gripper_controller/command', JointTrajectory, queue_size=10)

    # Wait until the publisher is ready
    rospy.sleep(1)

    # Create a JointTrajectory message
    trajectory_msg = JointTrajectory()

    # Specify the joint names controlled by the gripper (right_finger and left_finger)
    trajectory_msg.joint_names = ['right_finger', 'left_finger']

    # Create a JointTrajectoryPoint
    point = JointTrajectoryPoint()

    # Set desired joint positions (0.0 for closed, -1.0 ; 1.0 for open)
    point.positions = [0.0, 0.0]  # Open the gripper

    # Set the time it should take to reach the desired positions
    point.time_from_start = rospy.Duration(1.0)  # Reach the goal in 1 second

    # Add the point to the trajectory
    trajectory_msg.points.append(point)

    # Publish the trajectory command
    pub.publish(trajectory_msg)

    rospy.loginfo("Gripper command published!")

if __name__ == "__main__":
    try:
        control_gripper_with_publisher()
    except rospy.ROSInterruptException:
        pass
